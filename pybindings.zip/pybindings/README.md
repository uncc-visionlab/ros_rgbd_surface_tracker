Details on how to use this code can be found in the link below. 

[How to Convert your OpenCV C++ code Into a Python Module](http://www.learnopencv.com/how-to-convert-your-opencv-c-code-into-a-python-module)


# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://www.learnopencv.com/wp-content/uploads/2020/04/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
